from .plot import hinton_animation as hinton

__all__ = ["hinton"]
